# Person CNN, antrenat de la zero

Clasifică un decupaj grayscale în **persoană** sau **fundal**. Rețeaua este un CNN mic în PyTorch, cu ponderi inițializate aleatoriu. Nu se încarcă un checkpoint ImageNet sau YOLO.

Setul din `data/` are cadre de dronă și casete YOLO pentru clasa `person`. La antrenare, fiecare casetă devine un decupaj pozitiv. Pentru fiecare casetă se alege și un decupaj de fundal, de aceeași mărime, care nu se suprapune cu persoana.

## Instalare

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Pe Windows, activarea este `.venv\Scripts\activate`.

## Antrenare

Din rădăcina acestui repo:

```bash
python train_cnn_scratch_en.py
```

Implicit: 40 de epoci, imagini de 64×64, batch 16, dispozitiv `cpu`.

```bash
python train_cnn_scratch_en.py --epochs 40 --batch 16 --device cpu
```

Pe un Mac cu GPU Apple se poate folosi `--device mps`. Pe NVIDIA, `--device cuda`.

Ponderile și istoricul ajung în `runs/classify/cnn_scratch_person/`. Fișierul cel mai bun este `weights/best.pt`. La fiecare epocă se afișează loss-ul și acuratețea pe antrenare și pe validare.

Reluarea unei rulări întrerupte:

```bash
python train_cnn_scratch_en.py --resume
```

## Date

| Split | Imagini |
| --- | ---: |
| train | 82 |
| val | 9 |

Imaginile sunt un subset din [PULP-DroNet v3](https://github.com/pulp-platform/pulp-dronet), publicat sub [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Casetele de persoană sunt pseudo-etichete. Folosirea este necomercială, cu atribuire, iar lucrările derivate păstrează aceeași licență.
